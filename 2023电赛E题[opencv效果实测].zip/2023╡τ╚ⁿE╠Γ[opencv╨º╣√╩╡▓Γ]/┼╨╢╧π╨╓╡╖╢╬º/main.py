import cv2

# 回调函数，用于滚轮事件
def on_trackbar(position):
    pass

def main():
    # 读取图像文件
    image = cv2.imread('image.png')

    # 创建窗口
    cv2.namedWindow('Image')

    # 创建滚轮位置的滑动条
    cv2.createTrackbar('Hue Min', 'Image', 0, 255, on_trackbar)
    cv2.createTrackbar('Hue Max', 'Image', 0, 255, on_trackbar)
    cv2.createTrackbar('Saturation Min', 'Image', 0, 255, on_trackbar)
    cv2.createTrackbar('Saturation Max', 'Image', 0, 255, on_trackbar)
    cv2.createTrackbar('Value Min', 'Image', 0, 255, on_trackbar)
    cv2.createTrackbar('Value Max', 'Image', 0, 255, on_trackbar)

    while True:
        # 将图像转换为HSV颜色空间
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # 读取滚轮位置的滑动条值
        hue_min = cv2.getTrackbarPos('Hue Min', 'Image')
        hue_max = cv2.getTrackbarPos('Hue Max', 'Image')
        saturation_min = cv2.getTrackbarPos('Saturation Min', 'Image')
        saturation_max = cv2.getTrackbarPos('Saturation Max', 'Image')
        value_min = cv2.getTrackbarPos('Value Min', 'Image')
        value_max = cv2.getTrackbarPos('Value Max', 'Image')

        # 创建蒙版，提取目标颜色的区域
        lower_color = (hue_min, saturation_min, value_min)
        upper_color = (hue_max, saturation_max, value_max)
        mask = cv2.inRange(hsv, lower_color, upper_color)

        # 显示原始图像和蒙版
        cv2.imshow('Image', image)
        cv2.imshow('Mask', mask)

        # 按下 'q' 键退出
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 关闭窗口
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()