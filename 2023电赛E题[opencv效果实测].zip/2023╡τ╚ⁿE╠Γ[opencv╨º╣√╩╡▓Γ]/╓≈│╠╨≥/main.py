import cv2 as cv
import numpy as np


# 颜色阈值，可以根据需要进行调整
lower_red1 = np.array([128, 69, 94])
upper_red1 = np.array([179, 255, 124])
lower_red2 = np.array([0, 17, 158])
upper_red2 = np.array([25, 104, 192])
lower_red3 = np.array([0, 0, 0])
upper_red3 = np.array([130, 255, 255])

lower_green = np.array([0, 0, 0])
upper_green = np.array([255, 255, 241])

def get_rectangle_coordinates(rect):
    # 通过旋转矩形框的中心点、宽度和高度计算四个顶点的坐标
    center, size, angle = rect
    width = int(size[0])
    height = int(size[1])

    rect_points = cv.boxPoints(rect)
    rect_points = np.int0(rect_points)
    rect_points = rect_points.tolist()

    # 将顶点按照顺时针排序
    ordered_points = sorted(rect_points, key=lambda x: x[0])
    leftmost_points = ordered_points[:2]
    rightmost_points = ordered_points[2:]

    top_left = sorted(leftmost_points, key=lambda x: x[1])[0]
    bottom_left = sorted(leftmost_points, key=lambda x: x[1])[1]
    top_right = sorted(rightmost_points, key=lambda x: x[1])[0]
    bottom_right = sorted(rightmost_points, key=lambda x: x[1])[1]

    return [top_left, top_right, bottom_right, bottom_left]


# 打开摄像头
cap1 = cv.VideoCapture(1, cv.CAP_DSHOW)
cap2 = cv.VideoCapture(1, cv.CAP_DSHOW)
while True:
    # 读取图像帧
    ret, frame = cap1.read()
    ret1, frame1 = cap1.read()
    #ret2, frame2 = cap2.read()
    # 将图像转换为灰度图像
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    # 检测轮廓
    ret, binary = cv.threshold(gray, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU)
    cv.imshow('c', binary)

    # 执行轮廓检测
    contours, _ = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)

    # 初始化最小面积和对应的轮廓索引
    # 初始化最小面积和对应的轮廓索引
    min_area = float('inf')
    min_contour_index = -1

    for i, contour in enumerate(contours):
        # 进行矩形拟合
        rect = cv.minAreaRect(contour)
        epsilon = 0.05 * cv.arcLength(contour, True)
        approx = cv.approxPolyDP(contour, epsilon, True)

        # 计算轮廓面积
        area = cv.contourArea(contour)

        # 更新最小面积和对应的轮廓索引
        if area < min_area and rect[1][0] > 100 and rect[1][1] > 100 and rect[1][0] < 300 and rect[1][1] < 500:
            min_area = area
            min_contour_index = i
            min_rect_points = cv.boxPoints(rect).astype(int)

    # 输出最小矩形框的四个角的坐标值
    if min_contour_index != -1:
        for j, point in enumerate(min_rect_points):
            cv.circle(frame, tuple(point), 5, (0, 0, 255), -1)
            cv.putText(frame, f"{j + 1}: ({point[0]},{point[1]})", tuple(point), cv.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 0, 255), 1)
            print(f"{j + 1}: ({point[0]},{point[1]})")

        # 框出最小矩形框
        cv.drawContours(frame, [min_rect_points], 0, (0, 255, 0), 2)
    else:
        print("No valid rectangle found.")
    # 定义ROI
    roi = frame[12:432, 110:610]

    # 绘制矩形框
    cv.rectangle(frame, (110, 12), (610, 432), (0, 255, 0), 2)

    # 将ROI区域转换为HSV颜色空间
    hsv_roi = cv.cvtColor(roi, cv.COLOR_BGR2HSV)

    # 构建颜色掩膜
    red_mask1 = cv.inRange(hsv_roi, lower_red1, upper_red1)
    red_mask2 = cv.inRange(hsv_roi, lower_red2, upper_red2)
    red_mask3 = cv.inRange(hsv_roi, lower_red3, upper_red3)
    red_result = cv.bitwise_or(red_mask1, red_mask2,red_mask3)
    # 膨胀操作
    kernel = np.ones((5, 5), np.uint8)
    red_mask = cv.dilate(red_result, kernel, iterations=2)

    # 根据掩膜获得颜色区域
    red_result = cv.bitwise_and(roi, roi, mask=red_mask)

    # 寻找红色区域的轮廓
    contours, _ = cv.findContours(red_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

    # 寻找质心并绘制实心圆
    for contour in contours:
        # 计算区域的质心坐标
        M = cv.moments(contour)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"]+110)
            cY = int(M["m01"] / M["m00"]+15)
            # 计算区域的面积
            area = cv.contourArea(contour)
            # 设置红色区域面积的阈值
            if area >3 and area<5:
                # 在质心位置绘制实心圆
                cv.circle(roi, (cX, cY), 5, (0, 0, 255), -1)

            # 在图像上打印质心坐标
            text = "red: ({}, {})".format(cX, cY)
            cv.putText(roi, text, (cX -100, cY ), cv.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 2)

    # 将处理后的ROI放回原始帧中
    frame[12:432, 110:610] = roi

    # 显示识别结果

    #cv.imshow('Red', red_result)



    cv.imshow("result", frame)
    # 按下Esc键退出
    if cv.waitKey(1) == 27:
        break

# 关闭摄像头
cap1.release()
cap2.release()
cv.destroyAllWindows()